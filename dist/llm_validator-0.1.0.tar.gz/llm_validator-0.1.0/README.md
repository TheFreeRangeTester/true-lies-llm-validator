# LLM Validator

Una librería Python para validar respuestas de LLMs (Large Language Models) contra datos de referencia, con validación factual, semántica y de polaridad.

## 🚀 Características Principales

- **Validación Factual**: Extrae y valida campos específicos de las respuestas del LLM
- **Validación Semántica**: Compara similitud semántica con texto de referencia
- **Validación de Polaridad**: Verifica que el tono/actitud sea consistente
- **Mapeo Semántico**: Soporte para sinónimos y términos específicos del dominio
- **Configuración Flexible**: Campos personalizables y patrones de extracción
- **Múltiples Dominios**: Seguros, motocicletas, retail, banca y más

## 📦 Instalación

```bash
pip install llm-validator
```

## 🎯 Uso Rápido

### Concepto de "Facts"

Los **facts** son los valores que **SI O SI** deben estar presentes en la respuesta del LLM. Estos se expanden automáticamente usando el **semantic mapping** para incluir sinónimos y variaciones.

**Ejemplo:**
- **Fact**: `"coverage_type": "auto insurance"`
- **Semantic Mapping**: `"auto insurance": ["car insurance", "automobile insurance"]`
- **Resultado**: El sistema buscará "auto insurance", "car insurance" o "automobile insurance" en el candidate

### API Simplificada (Recomendada)

```python
from llm_validator.runner import validate_llm_response

# 1. FACTS - Los valores que SI O SI deben estar en el candidate
facts = {
    "policy_number": "POL-2024-001",
    "premium": "$850.00",
    "coverage_type": "auto insurance",
    "liability_limit": "$100,000",
    "expiry_date": "December 31, 2024"
}

# 2. REFERENCE TEXT - Texto de referencia para comparación semántica
reference_text = "Your auto insurance policy #POL-2024-001 has a premium of $850.00 per month..."

# 3. SEMANTIC MAPPING - Sinónimos que expanden los facts para validación
semantic_mapping = {
    "auto insurance": ["car insurance", "automobile insurance"],
    "liability": ["liability coverage", "liability protection"],
    "premium": ["monthly payment", "monthly cost"]
}

# 4. CANDIDATES - Respuestas del LLM a validar
candidates = [
    "Policy POL-2024-001 covers your automobile with monthly payments of $850.00...",
    "Your car insurance policy POL-2024-001 costs $850 monthly...",
    "Auto policy #POL-2024-001 has a $850.00 monthly premium..."
]

# 5. VALIDAR
results = validate_llm_response(
    facts=facts,
    reference_text=reference_text,
    candidates=candidates,
    semantic_mapping=semantic_mapping,
    threshold=0.7
)
```

## 🔧 Configuraciones Avanzadas

### Usando Dominios Predefinidos

```python
# Usar mapeo semántico basado en dominio
results = validate_llm_response(
    facts=facts,
    reference_text=reference_text,
    candidates=candidates,
    domain="insurance",  # Carga semantic_data/insurance.json
    threshold=0.7
)
```

### Configuración de Campos Personalizada

```python
# Configuración personalizada para extracción de campos
field_configs = {
    "stock": {
        "name": "stock",
        "patterns": [
            r'(\d+)\s+units?\s+available',
            r'in\s+stock\s+with\s+(\d+)',
            r'we\s+have\s+(\d+)\s+units?'
        ]
    }
}

results = validate_llm_response(
    facts=facts,
    reference_text=reference_text,
    candidates=candidates,
    field_configs=field_configs,
    threshold=0.7
)
```

## 📊 Resultados

La función devuelve un diccionario con información detallada:

```python
{
    "total_candidates": 3,
    "factual_pass": 1,
    "fully_valid": 1,
    "success_rate": 33.3,
    "results": [
        {
            "index": 1,
            "candidate": "...",
            "factual": {"is_valid": True, "details": {...}},
            "semantic": {
                "similarity_score": 0.85,
                "token_score": 0.90,
                "seq_score": 0.80,
                "semantic_boost": 0.05,
                "is_valid": True
            },
            "polarity": {"polarity_match": True, ...},
            "is_valid": True
        }
    ],
    "facts": {...},  # Los facts originales que se validaron
    "reference_text": "..."
}
```

## 🏗️ Dominios Soportados

### Seguros (`insurance`)
- `policy_number`: Números de póliza
- `premium`: Primas mensuales
- `coverage_type`: Tipos de cobertura
- `liability_limit`: Límites de responsabilidad
- `expiry_date`: Fechas de expiración

### Motocicletas (`motorcycle_dealership`)
- `motorcycle_model`: Modelos de motocicletas
- `price`: Precios
- `mileage`: Kilometraje
- `warranty`: Garantías
- `condition`: Condición

### Retail (`retail`)
- `product_name`: Nombres de productos
- `stock`: Inventario
- `price`: Precios
- `color`: Colores

### Banca (`banking`)
- `account_type`: Tipos de cuenta
- `balance`: Saldos
- `interest_rate`: Tasas de interés
- `account_number`: Números de cuenta

## 🎨 Ejemplos Completos

### Ejemplo: Validación de Seguros

```python
from llm_validator.runner import validate_llm_response

# Configuración para seguros
facts = {
    "policy_number": "POL-2024-001",
    "premium": "$850.00",
    "coverage_type": "auto insurance",
    "liability_limit": "$100,000",
    "expiry_date": "December 31, 2024"
}

reference_text = "Your auto insurance policy #POL-2024-001 has a premium of $850.00 per month..."

semantic_mapping = {
    "auto insurance": ["car insurance", "automobile insurance"],
    "liability": ["liability coverage", "liability protection"],
    "comprehensive": ["comprehensive coverage", "full coverage"],
    "premium": ["monthly payment", "monthly cost"],
    "policy": ["insurance policy", "coverage policy"]
}

candidates = [
    "Policy POL-2024-001 covers your automobile with monthly payments of $850.00...",
    "Your car insurance policy POL-2024-001 costs $850 monthly...",
    "Auto policy #POL-2024-001 has a $850.00 monthly premium..."
]

results = validate_llm_response(
    facts=facts,
    reference_text=reference_text,
    candidates=candidates,
    semantic_mapping=semantic_mapping,
    threshold=0.7
)
```

### Ejemplo: Validación de Inventario

```python
# Configuración para motocicletas
facts = {
    "motorcycle_model": "Honda CBR 600RR",
    "price": "$12,500",
    "mileage": "1500",
    "warranty": "6-month",
    "condition": "excellent"
}

reference_text = "The Honda CBR 600RR is available for $12,500..."

results = validate_llm_response(
    facts=facts,
    reference_text=reference_text,
    candidates=candidates,
    domain="motorcycle_dealership",  # Usa mapeo predefinido
    threshold=0.7
)
```

## 🔍 Validación Semántica Mejorada

La validación semántica incluye:

- **Token Overlap**: Comparación de tokens normalizados
- **Sequence Similarity**: Similitud de secuencia usando difflib
- **Semantic Boost**: Bonus por coincidencias de sinónimos
- **Weighted Scoring**: Peso mayor para tokens de hechos clave

### Scoring Semántico

```python
# Pesos de tokens:
# - Tokens de hechos (facts): peso 3.0
# - Sinónimos semánticos: peso 2.0  
# - Otros tokens: peso 1.0

# Score final = (token_score + seq_score) / 2 + semantic_boost
```

## 🔧 API Individual

### validate_all()

Para validar un solo candidate con todos los tipos de validación:

```python
from llm_validator import validate_all

# Facts que SI O SI deben estar en el candidate
facts = {
    "policy_number": "POL-2024-001",
    "premium": "$850.00",
    "coverage_type": "auto insurance"
}

reference_text = "Your auto insurance policy #POL-2024-001 has a premium of $850.00"

candidate = "Policy POL-2024-001 covers your automobile with monthly payments of $850.00"

# Semantic mapping para expandir los facts
semantic_mapping = {
    "auto insurance": ["car insurance", "automobile insurance"],
    "premium": ["monthly payment", "monthly cost"]
}

result = validate_all(
    candidate_text=candidate,
    facts=facts,  # ✅ Usa 'facts' en lugar de 'reference_values'
    reference_text=reference_text,
    semantic_mapping=semantic_mapping,
    threshold=0.7
)
```

## 🛠️ API Legacy

Para compatibilidad con versiones anteriores:

```python
from llm_validator.runner import run_validation_scenario

results = run_validation_scenario(
    scenario_name="insurance_policy",
    reference_text=reference_text,
    reference_values=facts,
    candidates=candidates,
    threshold=0.7,
    domain="insurance"
)
```

## 📁 Estructura del Proyecto

```
llm_validator/
├── __init__.py
├── core.py              # Funciones principales de validación
├── runner.py            # API de ejecución y reportes
├── utils.py             # Utilidades y extracción de campos
└── semantic_data/       # Mapeos semánticos por dominio
    ├── insurance.json
    ├── motorcycle_dealership.json
    ├── retail.json
    └── banking.json
```

## 🤝 Contribuir

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 🆕 Changelog

### v0.2.0 - API Mejorada
- ✅ Nueva función `validate_llm_response()` más intuitiva
- ✅ Parámetro `facts` en lugar de `reference_values` para mayor claridad
- ✅ Soporte mejorado para mapeos semánticos que expanden los facts
- ✅ Scoring semántico con boost por sinónimos
- ✅ Mejor formato de resultados con emojis
- ✅ Configuraciones de campos personalizables
- ✅ Dominios predefinidos para diferentes industrias

### v0.1.0 - Versión Inicial
- ✅ Validación factual básica
- ✅ Validación semántica
- ✅ Validación de polaridad
- ✅ API legacy con `run_validation_scenario()`
